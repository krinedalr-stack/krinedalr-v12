"use client";
import WeatherWidget from "@/components/WeatherWidget";
import WindGauge from "@/components/WindGauge";

const PHONE = process.env.NEXT_PUBLIC_SITE_PHONE ?? "0831762475";
const EMAIL = process.env.NEXT_PUBLIC_SITE_EMAIL ?? "krinedalr@gmail.com";
const ADDRESS = process.env.NEXT_PUBLIC_SITE_ADDRESS ?? "119 Academy Square, Navan, Co. Meath, C15 TY44";

export default function Home() {
  const cleanPhone = `+353${PHONE.replace(/\D/g,"")}`;
  return (
    <>
      <header className="header">
        <div className="brand">
          <img src="/logo.png" alt="Krinedal-R Logo" style={{height:42}} />
          <span>Krinedal-</span><span className="r">R</span>&nbsp;Construction
        </div>
        <a className="pill red" href={`tel:${cleanPhone}`}>24/7 After-Storm • Call {PHONE}</a>
      </header>

      <main className="main">
        <h1 className="h1">Luxury Tiling • Roofing • Painting</h1>
        <p className="sub">Crafted to last. Installed to perfection. Based in Meath with 24/7 support.</p>

        <img src="/qr.png" alt="QR to krinedalr.ie" className="qr" />

        <ul className="list">
          {["Luxury Bathrooms","Large-Format Tiling","Hidden Lighting","Roof Checks & Storm Repairs","Powerwashing & Landscaping"].map((item)=>(
            <li key={item}><span className="dot"></span>{item}</li>
          ))}
        </ul>

        <div style={{display:"flex",flexWrap:"wrap",gap:10,margin:"12px 0 8px"}}>
          <a className="btn call" href={`tel:${cleanPhone}`}>Call {PHONE}</a>
          <a className="btn whats" href={`https://wa.me/353${PHONE.replace(/\D/g,"")}`}>WhatsApp</a>
          <a className="btn mail" href={`mailto:${EMAIL}`}>Email Us</a>
        </div>

        <p className="sub"><strong className="r">WE BUILD — YOU RELAX</strong> • Luxury results, local costs.</p>

        <section className="grid">
          <div className="card">
            <h2 style={{marginTop:0}}>Weather Warnings (Met Éireann)</h2>
            <a className="pill" href="https://www.met.ie/warnings" target="_blank" rel="noopener">Open Live Warnings</a>
          </div>

          <div className="card">
            <h2 style={{marginTop:0}}>Live Wind Meter (Navan)</h2>
            <WindGauge lat={53.653} lon={-6.681} />
          </div>

          <div className="card">
            <h2 style={{marginTop:0}}>Local Forecast Snapshot</h2>
            <WeatherWidget lat={53.653} lon={-6.681} />
          </div>
        </section>
      </main>

      <footer className="footer">
        <p>© Krinedal-R Construction • {ADDRESS} • <a href={`mailto:${EMAIL}`}>{EMAIL}</a> • <a href={`tel:${cleanPhone}`}>{PHONE}</a></p>
        <p><a href="https://www.facebook.com" target="_blank" rel="noopener">Facebook: Krinedal-R</a> • Domain: krinedalr.ie</p>
      </footer>
    </>
  );
}
