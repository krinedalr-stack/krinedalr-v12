import "./globals.css";

export const metadata = {
  title: "Krinedal-R Construction & Storm Repair",
  description: "Luxury tiling, roofing, painting, landscaping, powerwashing. 24/7 After-Storm Response. Meath, Ireland."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
