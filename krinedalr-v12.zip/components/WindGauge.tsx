"use client";
import { useEffect, useState } from "react";

type Props = { lat: number; lon: number };

export default function WindGauge({ lat, lon }: Props) {
  const [speed, setSpeed] = useState<number | null>(null);
  const [gust, setGust] = useState<number | null>(null);
  const [ts, setTs] = useState<string>("");

  useEffect(() => {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&hourly=windspeed_10m,windgusts_10m&timezone=auto`;
    fetch(url).then(r => r.json()).then(d => {
      const idx = 0;
      setSpeed(d?.hourly?.windspeed_10m?.[idx] ?? null);
      setGust(d?.hourly?.windgusts_10m?.[idx] ?? null);
      setTs(new Date().toLocaleTimeString());
    }).catch(() => {});
  }, [lat, lon]);

  const color = (v:number|null) => {
    if (v==null) return "#9aa3b2";
    if (v < 20) return "#2ecc71";     // green
    if (v < 40) return "#ffbf00";     // amber
    return "#e53935";                 // red
  };

  return (
    <div style={{display:"flex",alignItems:"center",gap:16}}>
      <div style={{width:120,height:120,borderRadius:"50%",background:"#0f1115",border:"8px solid #2a2f3a",position:"relative",display:"grid",placeItems:"center"}}>
        <div style={{width:90,height:90,borderRadius:"50%",background: color(speed), opacity:0.25}}/>
        <div style={{position:"absolute",textAlign:"center"}}>
          <div style={{fontSize:24,fontWeight:800}}>{speed?.toFixed(0) ?? "--"}<span style={{fontSize:12}}> km/h</span></div>
          <div style={{fontSize:12, color:"#9aa3b2"}}>gusts: {gust?.toFixed(0) ?? "--"} km/h</div>
        </div>
      </div>
      <div style={{color:"#9aa3b2"}}>
        <div><strong>Status:</strong> {speed==null ? "Loading…" : speed < 20 ? "Calm / Green" : speed < 40 ? "Caution / Amber" : "Warning / Red"}</div>
        <div><strong>Updated:</strong> {ts || "--"}</div>
        <div style={{marginTop:8,fontSize:12}}>Source: Open‑Meteo (no API key)</div>
      </div>
    </div>
  );
}
