"use client";
import { useEffect, useState } from "react";

type Props = { lat: number; lon: number };
export default function WeatherWidget({ lat, lon }: Props) {
  const [data, setData] = useState<{temp:number|null; precip:number|null; wind:number|null}>({temp:null, precip:null, wind:null});
  const [ts, setTs] = useState("");

  useEffect(() => {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,precipitation,wind_speed_10m&timezone=auto`;
    fetch(url).then(r=>r.json()).then(d=>{
      setData({
        temp: d?.current?.temperature_2m ?? null,
        precip: d?.current?.precipitation ?? null,
        wind: d?.current?.wind_speed_10m ?? null
      });
      setTs(new Date().toLocaleTimeString());
    }).catch(()=>{});
  }, [lat, lon]);

  return (
    <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12}}>
      {[
        {label:"Temp", value: data.temp==null ? "--" : `${data.temp.toFixed(1)}°C`},
        {label:"Precip", value: data.precip==null ? "--" : `${data.precip.toFixed(1)} mm`},
        {label:"Wind", value: data.wind==null ? "--" : `${data.wind.toFixed(0)} km/h`}
      ].map((b)=>(
        <div key={b.label} style={{border:"1px solid #2a2f3a",background:"#0f1115",padding:14,borderRadius:12,textAlign:"center"}}>
          <div style={{color:"#9aa3b2",fontSize:12}}>{b.label}</div>
          <div style={{fontSize:22,fontWeight:800}}>{b.value}</div>
        </div>
      ))}
      <div style={{gridColumn:"1 / -1",color:"#9aa3b2",fontSize:12}}>Updated: {ts || "--"} • Source: Open‑Meteo</div>
    </div>
  );
}
