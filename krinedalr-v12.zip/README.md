# Krinedal-R v12

**Deploy steps**
1. Push this repo to GitHub.
2. Import to Vercel → New Project.
3. Add env vars:
   - NEXT_PUBLIC_SITE_PHONE=0831762475
   - NEXT_PUBLIC_SITE_EMAIL=krinedalr@gmail.com
   - NEXT_PUBLIC_SITE_ADDRESS="119 Academy Square, Navan, Co. Meath, C15 TY44"
4. Deploy. Add domain krinedalr.ie and www.krinedalr.ie
   - A record: 76.76.21.21
   - CNAME (www): cname.vercel-dns.com
